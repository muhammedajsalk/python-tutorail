string = "hello54236726hdfjds"
total = 0

for char in string:
    if char.isdigit():
        total += int(char)

print(total)

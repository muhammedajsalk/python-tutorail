import random

choices = ["rock", "paper", "scissors"]

def determine_winner(player_choice, computer_choice):
    if player_choice == computer_choice:
        return "It's a tie!"
    elif player_choice == "rock":
        if computer_choice == "paper":
            return "Computer wins!"
        else:
            return "Player wins!"
    elif player_choice == "paper":
        if computer_choice == "scissors":
            return "Computer wins!"
        else:
            return "Player wins!"
    elif player_choice == "scissors":
        if computer_choice == "rock":
            return "Computer wins!"
        else:
            return "Player wins!"

player_choice = input("Enter your choice (rock, paper, or scissors): ").lower()

computer_choice = random.choice(choices)

print("Player chooses:", player_choice)
print("Computer chooses:", computer_choice)

result = determine_winner(player_choice, computer_choice)
print(result)




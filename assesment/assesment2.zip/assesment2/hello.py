my_list = [1, 2, 3, 4, 5]
sum_of_list = sum(my_list)
print(sum_of_list)